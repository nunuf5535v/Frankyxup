case 'dataconta':
case 'datadaconta': {
  if (!q.trim()) return reply(`- Exemplo: ${prefix}dataconta 168274223`);

  const id = q.trim();
  const url = `https://world-ecletix.onrender.com/api/datadaconta?id=${encodeURIComponent(id)}`;

  try {
    const res = await fetch(url);
    const json = await res.json();

    if (!res.ok || !json.success || !json.datacriacao) {
      return reply("❌ Não foi possível obter a data de criação da conta.");
    }

    // Remove qualquer link (como o campo 'perfil') da mensagem
    let texto = json.datacriacao.replace(/https?:\/\/[^\s]+/g, '').trim();

    // Detecta raridade percentual (ex: 95.52%)
    const matchRaridade = texto.match(/(\d{2,3}\.\d{1,2})%/);
    const raridade = matchRaridade ? parseFloat(matchRaridade[1]) : null;

    // Adiciona tag especial se raridade for alta
    const tagRara = raridade && raridade >= 90
      ? `🔥 *Conta Ultra Rara (${raridade}%)!*`
      : '';

    const mensagem = `📅 ${texto}${tagRara ? `\n\n${tagRara}` : ''}`;

    reply(mensagem);

  } catch (err) {
    console.error("Erro no comando dataconta:", err);
    reply("🚨 Ocorreu um erro ao buscar a data da conta.");
  }
}
break;