╔═〔     🤖 lkzin bot ff     〕═╗
╚═════════════╝

⛽━━━━━🎮 𝙁𝙍𝙀𝙀 𝙁𝙄𝙍𝙀 𝙈𝙀𝙉𝙐 ━━━━━⛽

┃ 🔫 !likesff (ID)        – Likes do perfil  
┃ 🕹️ !visitasff (ID)      – Visitas do perfil  
┃ 📅 !dataconta (ID)       – Criação da conta  
┃ 🎖️ !primeff (ID)        – Conta Prime?  
┃ ⚡ !xpff (ID)            – Nível e XP  
┃ 📸 !ffperfil (ID)        – Perfil completo  
┃ 🏅 !guildaff (ID)        – Info da Guilda  
┃ 🚫 !checkban (ID)        – Banimento  
┃ 🔍 !ffmania (nome)      – Buscar jogador  

⛽━━━━━━━━━━━━━━━━━━━━⛽